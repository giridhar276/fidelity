# 3_read_table_to_csv_pandas_sqlalchemy.py
# Avoid pandas DBAPI warning by using SQLAlchemy engine for read_sql.
# Install once:
#   pip install snowflake-sqlalchemy sqlalchemy pandas
import pandas as pd
from sqlalchemy import create_engine, text
from snowflake.sqlalchemy import URL
from getpass import getpass

ACCOUNT   = "ZRINJJH-KF54576"
USER      = "GIRIDHAR276"
ROLE      = "ACCOUNTADMIN"
WAREHOUSE = "MY_WH"
DATABASE  = "MY_DB"
SCHEMA    = "PUBLIC"
TABLE     = "EMPLOYEE"

OUT_CSV = "employee_out.csv"
#PASSWORD = getpass("Snowflake password: ")
PASSWORD = "Nolimits@12345"

engine = create_engine(URL(
    user=USER,
    password=PASSWORD,
    account=ACCOUNT,
    role=ROLE,
    warehouse=WAREHOUSE,
    database=DATABASE,
    schema=SCHEMA,
))

# Use pandas.read_sql with a SQLAlchemy engine to avoid warnings
with engine.connect() as conn:
    df = pd.read_sql(text(f"SELECT * FROM {TABLE}"), conn)

df.to_csv(OUT_CSV, index=False)
print(f"Wrote {len(df)} rows to {OUT_CSV}")
