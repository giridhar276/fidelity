# 2_insert_from_csv_pandas_sqlalchemy.py
# Avoid pandas read_sql/to_sql warnings by using SQLAlchemy.
# Install once:
#   pip install snowflake-sqlalchemy sqlalchemy pandas
import pandas as pd
from sqlalchemy import create_engine, text
from snowflake.sqlalchemy import URL
from getpass import getpass

ACCOUNT   = "ZRINJJH-KF54576"
USER      = "GIRIDHAR276"
ROLE      = "ACCOUNTADMIN"
WAREHOUSE = "MY_WH"
DATABASE  = "MY_DB"
SCHEMA    = "PUBLIC"
TABLE     = "EMPLOYEE"

CSV_PATH = "employee.csv"
#PASSWORD = getpass("Snowflake password: ")
PASSWORD = "Nolimits@12345"

# Build engine with context (role/warehouse/db/schema)
engine = create_engine(URL(
    user=USER,
    password=PASSWORD,
    account=ACCOUNT,
    role=ROLE,
    warehouse=WAREHOUSE,
    database=DATABASE,
    schema=SCHEMA,
))

# Read CSV and normalize headers to Snowflake uppercase
df = pd.read_csv(CSV_PATH)
df.columns = [c.strip().upper().replace("-", "_").replace(" ", "_") for c in df.columns]


df.to_sql(TABLE, con=engine, schema=SCHEMA, if_exists='append', index=False, method='multi', chunksize=16000)

print(f"Inserted {len(df)} rows into {TABLE}.")
